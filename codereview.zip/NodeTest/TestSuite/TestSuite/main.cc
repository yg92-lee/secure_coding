#include <cstdio>
#include <cstring>

#include "node_test.h"
#include "typing_machine_test.h"

void main() {
	NodeTest();
	TypingMachineTest();

	return;
}