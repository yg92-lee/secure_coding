// Copyright 2018 Minkyu Jo

#ifndef TYPING_MACHINE_TEST_H_
#define TYPING_MACHINE_TEST_H_

void TypingMachineTest();

#endif  // TYPING_MACHINE_TEST_H_