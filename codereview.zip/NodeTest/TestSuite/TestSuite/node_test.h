// Copyright 2018 Minkyu Jo

#ifndef NODE_TEST_H_
#define NODE_TEST_H_

void NodeTest();

#endif  // NODE_TEST_H_