// Copyright 2018 Hanpil Kang
#include <vector>

std::vector<int> CountingSort(std::vector<int> V) {
  std::vector<int> counting_array(101, 0);
  for (int i = 0; i < static_cast<int>(V.size()); ++i) {
    ++counting_array[V[i]];
  }

  std::vector<int> sorted_array;
  for (int i = 0; i < static_cast<int>(counting_array.size()); ++i) {
    for (int j = 0; j < counting_array[i]; ++j) {
      sorted_array.push_back(i);
    }
  }

  return sorted_array;
}

#include <iostream>

int main() {
  for (int x : CountingSort({3, 1, 4})) {
    std::cout << x << " ";
  }
  std::cout << std::endl;
  for (int x : CountingSort({8, 3, 7, 2, 100, 100, 100, 2, 2, 100})) {
    std::cout << x << " ";
  }
  std::cout << std::endl;
}
